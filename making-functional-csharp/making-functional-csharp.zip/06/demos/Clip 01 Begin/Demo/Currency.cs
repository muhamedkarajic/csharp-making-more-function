﻿namespace Demo
{
    public class Currency
    {
        public string Symbol { get; set; }

        public override string ToString() => this.Symbol;
    }
}
