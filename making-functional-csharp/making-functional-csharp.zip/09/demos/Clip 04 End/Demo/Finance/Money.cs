﻿using Demo.Finance;

namespace Demo
{
    public abstract class Money
    {
    }
}
