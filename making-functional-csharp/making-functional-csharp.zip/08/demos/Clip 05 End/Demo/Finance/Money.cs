﻿namespace Demo.Finance
{
    public abstract class Money
    {
    }
}
