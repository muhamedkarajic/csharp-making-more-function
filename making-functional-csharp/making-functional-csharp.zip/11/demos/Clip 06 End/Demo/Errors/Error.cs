﻿namespace Demo.Errors
{
    public abstract class Error
    {
    }
}
