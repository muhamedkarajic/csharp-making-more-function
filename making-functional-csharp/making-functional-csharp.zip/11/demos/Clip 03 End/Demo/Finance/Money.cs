﻿namespace Demo
{
    public abstract class Money
    {
    }
}
