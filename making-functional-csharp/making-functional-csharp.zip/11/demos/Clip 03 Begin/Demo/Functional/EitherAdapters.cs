﻿using System;

namespace Demo.Functional
{
    public static class EitherAdapters
    {
    }
}
